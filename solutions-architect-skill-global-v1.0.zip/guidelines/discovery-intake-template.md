# Discovery Intake Template

(Use this to structure context gathering.)
# Cost Estimator

(Full logic in prompt.)
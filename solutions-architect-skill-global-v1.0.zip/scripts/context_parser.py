# Context Parser

(Full logic in prompt.)
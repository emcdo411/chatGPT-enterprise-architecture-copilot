# Risk Scorer

(Full logic in prompt.)